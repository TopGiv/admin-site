<!DOCTYPE html>

<html>
    
<head>

	
        
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">

	<link rel="shortcut icon" href="<?php echo base_url()?>assets/img/logo.png" />
	<link rel="icon" sizes="16x16 32x32 "type="image/x-icon"  href="<?php echo base_url()?>assets/img/logo.png">
	<link rel="icon" sizes="32x32" href="<?php echo base_url()?>assets/img/logo.png">
	<link rel="icon" sizes="192x192" href="<?php echo base_url()?>assets/img/logo.png">


	<link rel="apple-touch-icon-precomposed" sizes="152x152" href="<?php echo base_url()?>assets/img/logo.png">
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo base_url()?>assets/img/logo.png">
	<link rel="apple-touch-icon-precomposed" sizes="120x120" href="<?php echo base_url()?>assets/img/logo.png">
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo base_url()?>assets/img/logo.png">
	<link rel="apple-touch-icon-precomposed" sizes="180x180" href="<?php echo base_url()?>assets/img/logo.png">
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo base_url()?>assets/img/logo.png">
	<link rel="apple-touch-icon-precomposed" href="<?php echo base_url()?>assets/img/logo.png">
	
	<link href="<?php echo base_url()?>assets/css/screen.css" media="screen" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="<?php echo base_url()?>assets/jqwidgets/styles/jqx.base.css" type="text/css" />
	
    <title>TopGiv</title>
	
	<style type="text/css">
		.jqx-grid-cell { border: none; }
		.jqx-grid-column-header { border: none; }
	</style>
    
</head>

<body>
        
    <div class="header alternate-bg">
        <div class="wrapper">
                
            <nav class="navigation">
				<a href="<?php echo base_url()?>">
					<img src="<?php echo base_url()?>assets/img/logo.png" width="48px" height="48px" class="navigation-logo">
				</a>

				<ul class="navigation-elements">
					<li class="navigation-item-selected"><a href="#">Users</a></li>
					<li class="navigation-item"><a href="<?php echo base_url().'index.php/admin/news'?>">News</a></li>
					<li class="navigation-item"><a href="<?php echo base_url().'index.php/admin/events'?>">Events</a></li>
					<li class="navigation-item"><a href="<?php echo base_url().'index.php/admin/signOut'?>">Logout</a></li>
				</ul>
			</nav>
			
			<div id='jqxWidget' style="width:100%">
				<h1 class="header-title" style="font-size: 35px">USERS INFORMATION</h1>
				<div id="user_tb"></div>
				<br>
				<h1 class="header-title" style="font-size: 35px">USER'S DONATION DETAILS</h1>
				<div id="donation_tb"></div>
			</div>
			
			
		</div>
	</div>
	
	<script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxcore.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxdata.js"></script> 
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxbuttons.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxscrollbar.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxmenu.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxgrid.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxgrid.columnsresize.js"></script> 
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxgrid.selection.js"></script> 
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxlistbox.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxdropdownlist.js"></script>
	
	<script type="text/javascript">
        $(document).ready(function () {
            // prepare the data
            
            var source =
            {
                datatype: "json",
                datafields:
                [
                    { name: 'id', type: 'string' }, 
					{ name: 'name', type: 'string' }, 
					{ name: 'mail', type: 'string' }
                ],
                url: "<?php echo base_url()?>index.php/admin/users"
            };
            var dataAdapter = new $.jqx.dataAdapter(source);

            $("#user_tb").jqxGrid(
            {
                width: '100%',
				height: '100%',
                source: dataAdapter,
                columnsresize: true,
				altRows: true,
                columns: [
                  { text: 'Name', datafield: 'name', width: 100 },
                  { text: 'Email', datafield: 'mail', width: 'auto' }
                ]
            });
			
			initDonationTable(-1);
			
			$("#user_tb").on('rowselect', function (event) {
				rowindex = event.args.rowindex;
				rowdata = $("#user_tb").jqxGrid('getrowdata', rowindex);
				initDonationTable(rowdata.id);
			});
			
			function initDonationTable(uid) {
				var donation_source = {
					datatype: "json",
					datafields:
					[
						{ name: 'id', type: 'string' }, 
						{ name: 'amount', type: 'string' }, 
						{ name: 'date', type: 'string' }, 
						{ name: 'kind', type: 'string' }
					],
					url: "<?php echo base_url()?>index.php/admin/history?uid=" + uid
				};
				var donation_dataAdapter = new $.jqx.dataAdapter(donation_source);

				$("#donation_tb").jqxGrid(
				{
					width: '100%',
					source: donation_dataAdapter,
					columnsresize: true,
					altRows: true,
					columns: [
					  { text: 'Donation Amount', datafield: 'amount', width: 200 },
					  { text: 'Donation Date', datafield: 'date', width: 200 },
					  { text: 'Donation Kind', datafield: 'kind', width: 'auto' }
					]
				});
			}

        });
    </script>
	
</body>
    
</html>
