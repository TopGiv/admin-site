<!DOCTYPE html>

<html>
    
<head>

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">

	<link rel="shortcut icon" href="<?php echo base_url()?>assets/img/logo.png" />
	<link rel="icon" sizes="16x16 32x32 "type="image/x-icon"  href="<?php echo base_url()?>assets/img/logo.png">
	<link rel="icon" sizes="32x32" href="<?php echo base_url()?>assets/img/logo.png">
	<link rel="icon" sizes="192x192" href="<?php echo base_url()?>assets/img/logo.png">


	<link rel="apple-touch-icon-precomposed" sizes="152x152" href="<?php echo base_url()?>assets/img/logo.png">
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo base_url()?>assets/img/logo.png">
	<link rel="apple-touch-icon-precomposed" sizes="120x120" href="<?php echo base_url()?>assets/img/logo.png">
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo base_url()?>assets/img/logo.png">
	<link rel="apple-touch-icon-precomposed" sizes="180x180" href="<?php echo base_url()?>assets/img/logo.png">
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo base_url()?>assets/img/logo.png">
	<link rel="apple-touch-icon-precomposed" href="<?php echo base_url()?>assets/img/logo.png">
	
	<link href="<?php echo base_url()?>assets/css/screen.css" media="screen" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="<?php echo base_url()?>assets/jqwidgets/styles/jqx.base.css" type="text/css" />
	
    <title>TopGiv</title>
	
	<style type="text/css">
		.jqx-grid-cell {  border: none;  }
		.jqx-grid-column-header { border: none; }
		.text-input
        {
            height: 21px;
            width: 150px;
        }
        .register-table
        {
            margin-top: 10px;
            margin-bottom: 10px;
        }
        .register-table td, 
        .register-table tr
        {
            margin: 0px;
            padding: 2px;
            border-spacing: 0px;
            border-collapse: collapse;
            font-family: Verdana;
            font-size: 12px;
        }
        h3 
        {
            display: inline-block;
            margin: 0px;
        }
	</style>
    
</head>

<body>
        
    <div class="header alternate-bg">
        <div class="wrapper">
                
            <nav class="navigation">
				<a href="<?php echo base_url()?>">
					<img src="<?php echo base_url()?>assets/img/logo.png" width="48px" height="48px" class="navigation-logo">
				</a>

				<ul class="navigation-elements">
					<li class="navigation-item"><a href="<?php echo base_url().'index.php/admin/user'?>">Users</a></li>
					<li class="navigation-item"><a href="<?php echo base_url().'index.php/admin/news'?>">News</a></li>
					<li class="navigation-item-selected"><a href="#">Events</a></li>
					<li class="navigation-item"><a href="<?php echo base_url().'index.php/admin/signOut'?>">Logout</a></li>
				</ul>
			</nav>
			
			<div id='jqxWidget' style="width:100%">
				<input type="button" value="Add Events" id="addEventsButton" style="margin-bottom:20px;">
				<div id="events_tb"></div>
			</div>
			
			<div id="register" style="display: none; position: fixed; left: 50%; top: 50%;">
				<div><h3>Add Events</h3></div>
				<div>
					<form id="addForm" action="<?php echo base_url().'index.php/admin/addEvents'?>" enctype="multipart/form-data" method="post">
						<table class="register-table">
							<tr>
								<td>Thumb:</td>
								<td><input type="file" name="thumb" id="thumb"></td>
							</tr>
							<tr>
								<td>Title:</td>
								<td><input type="text" id="title" name="title" class="text-input" style="width:420px;" /></td>
							</tr>
							<tr>
								<td>Content:</td>
								<td><textarea id="content" name="content" rows="4" cols="50" class="text-input" style="width:420px;height:100px"></textarea></td>
							</tr>
							<tr>
								<td>Place:</td>
								<td><input type="text" id="place" name="place" class="text-input" style="width:420px;" /></td>
							</tr>
							
							<tr>
								<td colspan="2" style="text-align: center;"><input type="submit" value="Save" id="sendButton" /></td>
							</tr>
						</table>
					</form>
				</div>
			</div>
			
			<div id="updater" style="display: none; position: fixed; left: 50%; top: 50%;">
				<div><h3>Update Events</h3></div>
				<div>
					<form id="updateForm" action="<?php echo base_url().'index.php/admin/updateEvents'?>" enctype="multipart/form-data" method="post">
						<table class="register-table">
							<tr>
								<td>Thumb:</td>
								<td><input type="file" name="thumb1" id="thumb1"></td>
							</tr>
							<tr>
								<td>Title:</td>
								<td><input type="text" id="title1" name="title1" class="text-input" style="width:420px;" /></td>
							</tr>
							<tr>
								<td>Content:</td>
								<td><textarea id="content1" name="content1" rows="4" cols="50" class="text-input" style="width:420px;height:100px"></textarea></td>
							</tr>
							<tr>
								<td>Place:</td>
								<td><input type="text" id="place1" name="place1" class="text-input" style="width:420px;" /></td>
							</tr>
							<input type="hidden" id="id" name="id" value="" />
							<tr>
								<td colspan="2" style="text-align: center;"><input type="submit" value="Save"/></td>
							</tr>
						</table>
					</form>
				</div>
			</div>
			
		</div>	
	</div>
	
	<script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxcore.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxdata.js"></script> 
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxbuttons.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxscrollbar.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxmenu.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxgrid.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxgrid.columnsresize.js"></script> 
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxgrid.selection.js"></script> 
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxlistbox.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxdropdownlist.js"></script>
	<script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxwindow.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxcheckbox.js"></script>
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxpanel.js"></script>
	<script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxvalidator.js"></script> 
	
	<script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxexpander.js"></script> 
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxcalendar.js"></script> 
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxdatetimeinput.js"></script> 
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxmaskedinput.js"></script> 
    <script type="text/javascript" src="<?php echo base_url()?>assets/jqwidgets/jqxinput.js"></script> 
	
	<script type="text/javascript">
		
        $(document).ready(function () {
           
		   var imagerenderer = function (row, datafield, value) {
                return '<img style="margin-left: 5px;margin-top:5px" height="80" width="70" src="' + value + '"/>';
            }
			
			var textrenderer = function (row, datafield, value) {
                return '<div style="margin-top:5px">' + value + '</div>';
            }
			
			var delrenderer = function (row, datafield, value) {
                return '<a href="#" onclick="onDelete('+value+')"><img style="margin-left: 5px;margin-top:5px" height="30" width="30" src="<?php echo base_url()?>assets/img/del.png"/></a>';
            }
			
			var source = {
                datatype: "json",
                datafields:
                [
                    { name: 'id', type: 'string' }, 
					{ name: 'date', type: 'string' }, 
					{ name: 'title', type: 'string' }, 
					{ name: 'content', type: 'string' },
					{ name: 'place', type: 'string' },					
					{ name: 'image', type: 'string' }
                ],
                url: "<?php echo base_url()?>index.php/admin/eventsList"
            };
            var dataAdapter = new $.jqx.dataAdapter(source);

            $("#events_tb").jqxGrid(
            {
                width: '100%',
				
				autorowheight: true,
                autoheight: true,
                source: dataAdapter,
                columnsresize: false,
				altRows: true,
                columns: [
				  { text: 'Thumb', datafield: 'image', width: 80, cellsrenderer: imagerenderer },
                  { text: 'Title', datafield: 'title', width: 200, cellsrenderer: textrenderer },
				  { text: 'Create Date', datafield: 'date', width: 100, cellsrenderer: textrenderer },
                  { text: 'Content', datafield: 'content', width: 'auto', cellsrenderer: textrenderer },
				  { text: 'Place', datafield: 'place', width: 100, cellsrenderer: textrenderer },
				  { text: '#', datafield: 'id', width: 50, cellsrenderer: delrenderer },
                ]
            });
			
			
			$("#events_tb").on('rowdoubleclick', function (event) {
				rowindex = event.args.rowindex;
				rowdata = $("#events_tb").jqxGrid('getrowdata', rowindex);
				
				$("#id").val(rowdata.id);
				$("#title1").val(rowdata.title);
				$("#content1").val(rowdata.content);
				$("#place1").val(rowdata.place);
				$('#updater').jqxWindow('open');
			});
			
			$('#register').jqxWindow({  
				width: 500,
				height: 310, 
				resizable: false,
				cancelButton: $('#cancelButton')
			});
			
			$('#updater').jqxWindow({  
				width: 500,
				height: 310, 
				resizable: false,
				cancelButton: $('#cancelButton')
			});
			
			// initialize validator.
            $('#addForm').jqxValidator({
                hintType: 'label',
                animationDuration: 0,
				rules: [
						{ input: '#title', message: 'Title is required!', action: 'keyup, blur', rule: 'required' },
						{ input: '#content', message: 'Content is required!', action: 'keyup, blur', rule: 'required' }
					]
            });
			
			$('#updateForm').jqxValidator({
                hintType: 'label',
                animationDuration: 0,
				rules: [
						{ input: '#title1', message: 'Title is required!', action: 'keyup, blur', rule: 'required' },
						{ input: '#content1', message: 'Content is required!', action: 'keyup, blur', rule: 'required' }
					]
            });
			
			$('#register').jqxWindow('close');
			
			$("#addEventsButton").on('click', function (event) {
				$('#register').jqxWindow('open');
			});

        });
		
		function onDelete(value) {
			var result = confirm("Want to delete?");
			if (result) {
				location.href = "<?php echo base_url().'index.php/admin/delEvents?id='?>" + value;
			}
		}
    </script>
	
</body>
    
</html>
