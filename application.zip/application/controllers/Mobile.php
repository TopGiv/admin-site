<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once(APPPATH . 'libraries/Stripe/Stripe.php');

class Mobile extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url');

		$this->load->model('mobile_model','model',TRUE);
	}
	
	public function index()
	{
		$this->load->view('home');
	}

  
	public function signIn() {
		
		$mail = $this->input->get('mail');
		//$pwd = $this->input->get('pwd');
		
		if ($mail==='' /*|| $pwd===''*/) {
			echo json_encode(array('stat'=>0, 'msg'=>'signIn error!', 'uid'=>''));
			exit;
		}
		
		if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
			echo json_encode(array('stat'=>0, 'msg'=>'email address is considered invalid!', 'uid'=>''));
			exit;
		}
		
		echo json_encode($this->model->signIn($mail/*, md5($pwd)*/));
	}
	
	public function signUp() {
		$mail = $this->input->get('mail');
		//$pwd = $this->input->get('pwd');
		
		if ($mail==='' /*|| $pwd===''*/) {
			echo json_encode(array('stat'=>0, 'msg'=>'signIn error!', 'uid'=>''));
			exit;
		}
		
		if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
			echo json_encode(array('stat'=>0, 'msg'=>'email address is considered invalid!', 'uid'=>''));
			exit;
		}
		
		/************
		if (!$this->model->isExistEmail($mail)) {
			echo json_encode($this->model->signUp($mail));
			exit;
		} 
		
		echo json_encode(array('stat'=>0, 'msg'=>'The mail is exist.', 'uid'=>''));
		*************/
		
		echo json_encode($this->model->signUp($mail));
	}
	
	public function updateCardInfo() {
		$uid = $this->input->get('uid');
		$card_number = $this->input->get('card_number');
		$card_name = $this->input->get('card_name');
		$cvc = $this->input->get('cvc');
		
		echo json_encode($this->model->updateCardInfo($uid, $card_number, $cvc, $card_name));
	}
	
	public function history() {
		$uid = $this->input->get('uid');
		$data = $this->model->getHistoryList($uid);
		echo json_encode(array('stat'=>1, 'msg'=>'success', 'data'=>$data));
	}
	
	public function addHistory() {
		$mail = $this->input->get('mail');
		$amount = $this->input->get('amount');
		$date = $this->input->get('date');
		$kind = $this->input->get('kind');
		$token = $this->input->get('token');
		$currency = "USD";
		
		$stripe = array(
			  "secret_key"      => "sk_test_ITY6jZ8PP0hdkY25MuXsW3wv",
			  "publishable_key" => "pk_test_g8WKfRukyzUdNWy0lJ7cFna5"
			);
		
		
		try {
			Stripe::setApiKey($stripe['secret_key']);
			
			$charge = Stripe_Charge::create(array(
	                        "amount" => $amount*100,
	                        "currency" => $currency,
	                        "card" => $token,
	                        "description" => "Stripe Payment"
	                ));
			
			echo json_encode($this->model->addHisstory($mail, $amount, $date, $kind));
			exit();
			
		} catch (Stripe_CardError $e) {
	            echo json_encode(array('stat' => 0, 'msg' => $e->getMessage()));
	            exit();
	        } catch (Stripe_InvalidRequestError $e) {
	            // Invalid parameters were supplied to Stripe's API
	            echo json_encode(array('stat' => 0, 'msg' => $e->getMessage()));
	            exit();
	        } catch (Stripe_AuthenticationError $e) {
	            // Authentication with Stripe's API failed
	            echo json_encode(array('stat' => 0, 'msg' => $e->getMessage()));
	            exit();
	        } catch (Stripe_ApiConnectionError $e) {
	            // Network communication with Stripe failed
	            echo json_encode(array('stat' => 0, 'msg' => $e->getMessage()));
	            exit();
	        } catch (Stripe_Error $e) {
	            // Display a very generic error to the user, and maybe send
	            echo json_encode(array('stat' => 0, 'msg' => $e->getMessage()));
	            exit();
	        } catch (Exception $e) {
	            // Something else happened, completely unrelated to Stripe
	            echo json_encode(array('stat' => 0, 'msg' => $e->getMessage()));
	            exit();
	        }
	        
	        echo json_encode(array('stat'=>0, 'msg'=>'payment error!'));
		
	}
	
	public function news() {
		$data = $this->model->getNewsList();
		echo json_encode(array('stat'=>1, 'msg'=>'success', 'data'=>$data));
	}
	
	public function addNews() {
		$uid = $this->input->get('uid');
		$title = $this->input->get('title');
		$content = $this->input->get('content');
		$date = $this->input->get('date');
		
		echo json_encode($this->model->addNews($uid, $date, $title, $content));
	}
	
	public function updateNews() {
		$uid = $this->input->get('uid');
		$id = $this->input->get('id');
		$title = $this->input->get('title');
		$content = $this->input->get('content');
		
		echo json_encode($this->model->updateNews($uid, $id, $title, $content));
	}
	
	public function delNews() {
		$uid = $this->input->get('uid');
		$id = $this->input->get('id');
		
		echo json_encode($this->model->delNews($uid, $id));
	}
	
	public function uploadNewsImage() {
		$uid = $this->input->get('uid');
		$id = $this->input->get('id');
		
		$result = array('stat'=>0, 'msg'=>'upload error!', 'uid'=>$uid);
	
		$config['upload_path']          = $config['base_url'].'upload/photo';
		$config['allowed_types']        = 'gif|jpg|png';
		$config['max_size']             = 100;
		$config['max_width']            = 1024;
		$config['max_height']           = 768;
	
		$this->load->library('upload', $config);
	
		if ($this->upload->do_upload('userfile')) {
			$data = $this->upload->data();
			$path = $config['base_url'].'upload/news/'.$data['file_name'];
			$result = $this->model->updateNewsImage($uid, $id, $path);
		}
	
		echo json_encode($result);
	}
	
	public function events() {
		$data = $this->model->getEventsList();
		echo json_encode(array('stat'=>1, 'msg'=>'success', 'data'=>$data));
	}
	
	public function addEvents() {
		$uid = $this->input->get('uid');
		$title = $this->input->get('title');
		$content = $this->input->get('content');
		$date = $this->input->get('date');
		$place = $this->input->get('place');
		
		echo json_encode($this->model->addEvents($uid, $date, $title, $content, $place));
	}
	
	public function updateEvents() {
		$uid = $this->input->get('uid');
		$title = $this->input->get('title');
		$content = $this->input->get('content');
		$id = $this->input->get('id');
		$place = $this->input->get('place');
		
		echo json_encode($this->model->updateEvents($uid, $id, $title, $content, $place));
	}
	
	public function delEvents() {
		$uid = $this->input->get('uid');
		$id = $this->input->get('id');
		
		echo json_encode($this->model->delEvents($uid, $id));
	}
	
	public function uploadEventsImage() {
		$uid = $this->input->get('uid');
		$id = $this->input->get('id');
		
		$result = array('stat'=>0, 'msg'=>'upload error!', 'uid'=>$uid);
	
		$config['upload_path']          = $config['base_url'].'upload/photo';
		$config['allowed_types']        = 'gif|jpg|png';
		$config['max_size']             = 100;
		$config['max_width']            = 1024;
		$config['max_height']           = 768;
	
		$this->load->library('upload', $config);
	
		if ($this->upload->do_upload('userfile')) {
			$data = $this->upload->data();
			$path = $config['base_url'].'upload/events/'.$data['file_name'];
			$result = $this->model->updateNewsImage($uid, $id, $path);
		}
	
		echo json_encode($result);
	}
	
	public function mail() {
		$this->load->library('email');

		$subject = 'This is a test';
		$message = '<p>This message has been sent for testing purposes.</p>';
		
		$result = $this->email
		        ->from('talent@popnus.com')
		        //->reply_to('yoursecondemail@somedomain.com')    // Optional, an account where a human being reads.
		        ->to('codeghost112075@gmail.com')
		        ->subject($subject)
		        ->message($message)
		        ->send();
		
		var_dump($result);
		echo '<br />';
		echo $this->email->print_debugger();
	}

}
