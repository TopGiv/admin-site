<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
		$this->load->model('admin_model','model',TRUE);
	}

	public function index() {
		$this->load->view('login');
	}
	
	public function signIn() {
		$mail = $this->input->post('mail');
		$password = $this->input->post('password');
		
		if ($this->model->signIn($mail, md5($password))) {
			$user = array('mail'=>$mail, 'password'=>$password);
			$this->session->set_userdata('user',$user);
			
			echo json_encode(array('stat'=>1, 'msg'=>'ok.', 'url'=>base_url().'index.php/admin/user'));
			exit();
		} 
		
		echo json_encode(array('stat'=>0, 'msg'=>'Not registered user.', 'url'=>''));
	}
	
	public function signOut() {
		$this->session->unset_userdata('user');
		header("Location: " . base_url());
	}
	
	public function users() {
		/*if (!isset($this->session->userdata['user']))
			header("Location: " . base_url());*/
		
		echo json_encode($this->model->getUserList());
	}
	
	public function history() {
		if (!isset($this->session->userdata['user']))
			header("Location: " . base_url());
		
		$uid = $this->input->get('uid');
		echo json_encode($this->model->getHistoryList($uid));
	}
	
	public function news() {
		if (!isset($this->session->userdata['user']))
			header("Location: " . base_url());
		
		$this->load->view('news');
	}
	
	public function newsList() {
		if (!isset($this->session->userdata['user']))
			header("Location: " . base_url());
		
		echo json_encode($this->model->getNewsList());
	}
	
	public function addNews() {
		if (!isset($this->session->userdata['user']))
			header("Location: " . base_url());
		
		$title = $this->input->post('title');
		$content = $this->input->post('content');
		$date = time();
		
		if ($_FILES['thumb']['name'] != '') {
		
			$fileName = $_FILES['thumb']['name'];
			$ext = pathinfo($fileName, PATHINFO_EXTENSION);
			$fileName = time().'.'.$ext;
			
			$config1 = array();
			$config1['image_library'] = 'gd2';
			$config1['allowed_types'] = 'gif|jpg|png';
			$config1['source_image'] = $_FILES['thumb']['tmp_name'];
			$config1['new_image'] = 'upload/news/'.$fileName;
			$config1['maintain_ratio'] = TRUE;
			$config1['width'] = 500;
			$config1['height'] = 500;
			$config1['max_size'] = 0;
			$config1['max_width'] = 0;
			$config1['max_height'] = 0;
			
			$this->load->library('image_lib', $config1);
			
			if ($this->image_lib->resize()) {
				$path = base_url() . 'upload/news/' . $fileName;
				$this->model->addNews($date, $title, $content, $path);
			} else {
				$this->model->addNews($date, $title, $content);
			}
		} else {
			$this->model->addNews($date, $title, $content);
		}
		
		$this->load->view('news');
	}
	
	public function updateNews() {
		if (!isset($this->session->userdata['user']))
			header("Location: " . base_url());
		
		$id = $this->input->post('id');
		$title = $this->input->post('title1');
		$content = $this->input->post('content1');
		$date = time();
		
		if ($_FILES['thumb1']['name'] != '') {
		
			$fileName = $_FILES['thumb1']['name'];
			$ext = pathinfo($fileName, PATHINFO_EXTENSION);
			$fileName = time().'.'.$ext;
			
			$config1 = array();
			$config1['image_library'] = 'gd2';
			$config1['allowed_types'] = 'gif|jpg|png';
			$config1['source_image'] = $_FILES['thumb1']['tmp_name'];
			$config1['new_image'] = 'upload/news/'.$fileName;
			$config1['maintain_ratio'] = TRUE;
			$config1['width'] = 500;
			$config1['height'] = 500;
			$config1['max_size'] = 0;
			$config1['max_width'] = 0;
			$config1['max_height'] = 0;
			
			$this->load->library('image_lib', $config1);
			
			if ($this->image_lib->resize()) {
				$path = base_url() . 'upload/news/' . $fileName;
				$this->model->updateNews($id, $title, $content, $path);
			} else {
				$this->model->updateNews($id, $title, $content);
			}
		} else {
			$this->model->updateNews($id, $title, $content);
		}
		
		$this->load->view('news');
	}
	
	public function delNews() {
		if (!isset($this->session->userdata['user']))
			header("Location: " . base_url());
		
		$id = $this->input->get('id');
		
		$this->model->delNews($id);
		
		$this->load->view('news');
	}
	
	public function events() {
		if (!isset($this->session->userdata['user']))
			header("Location: " . base_url());
		
		$this->load->view('events');
	}
	
	public function eventsList() {
		if (!isset($this->session->userdata['user']))
			header("Location: " . base_url());
		
		echo json_encode($this->model->getEventsList());
	}
	
	public function addEvents() {
		if (!isset($this->session->userdata['user']))
			header("Location: " . base_url());
		
		$title = $this->input->post('title');
		$content = $this->input->post('content');
		$date = time();
		$place = $this->input->post('place');
		
		if ($_FILES['thumb']['name'] != '') {
		
			$fileName = $_FILES['thumb']['name'];
			$ext = pathinfo($fileName, PATHINFO_EXTENSION);
			$fileName = time().'.'.$ext;
			
			$config1 = array();
			$config1['image_library'] = 'gd2';
			$config1['allowed_types'] = 'gif|jpg|png';
			$config1['source_image'] = $_FILES['thumb']['tmp_name'];
			$config1['new_image'] = 'upload/events/'.$fileName;
			$config1['maintain_ratio'] = TRUE;
			$config1['width'] = 500;
			$config1['height'] = 500;
			$config1['max_size'] = 0;
			$config1['max_width'] = 0;
			$config1['max_height'] = 0;
			
			$this->load->library('image_lib', $config1);
			
			if ($this->image_lib->resize()) {
				$path = base_url() . 'upload/events/' . $fileName;
				$this->model->addEvents($date, $title, $content, $place, $path);
			} else {
				$this->model->addEvents($date, $title, $content, $place);
			}
		} else {
			$this->model->addEvents($date, $title, $content, $place);
		}
		
		$this->load->view('events');
	}
	
	public function updateEvents() {
		if (!isset($this->session->userdata['user']))
			header("Location: " . base_url());
		
		$title = $this->input->post('title1');
		$content = $this->input->post('content1');
		$id = $this->input->post('id');
		$place = $this->input->post('place1');
		
		if ($_FILES['thumb1']['name'] != '') {
		
			$fileName = $_FILES['thumb1']['name'];
			$ext = pathinfo($fileName, PATHINFO_EXTENSION);
			$fileName = time().'.'.$ext;
			
			$config1 = array();
			$config1['image_library'] = 'gd2';
			$config1['allowed_types'] = 'gif|jpg|png';
			$config1['source_image'] = $_FILES['thumb1']['tmp_name'];
			$config1['new_image'] = 'upload/events/'.$fileName;
			$config1['maintain_ratio'] = TRUE;
			$config1['width'] = 500;
			$config1['height'] = 500;
			$config1['max_size'] = 0;
			$config1['max_width'] = 0;
			$config1['max_height'] = 0;
			
			$this->load->library('image_lib', $config1);
			
			if ($this->image_lib->resize()) {
				$path = base_url() . 'upload/events/' . $fileName;
				$this->model->updateEvents($id, $title, $content, $place, $path);
			} else {
				$this->model->updateEvents($id, $title, $content, $place);
			}
		} else {
			$this->model->updateEvents($id, $title, $content, $place);
		}
		
		$this->load->view('events');
	}
	
	public function delEvents() {
		if (!isset($this->session->userdata['user']))
			header("Location: " . base_url());
		
		$id = $this->input->get('id');
		
		$this->model->delEvents($id);
		
		$this->load->view('events');
	}
	
	// view
	
	public function user() {
		if (!isset($this->session->userdata['user']))
			header("Location: " . base_url());
		
		$this->load->view('user');
	}
}
