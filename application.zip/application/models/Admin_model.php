<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model {

  function signIn($mail, $password) {
	$result = array('stat'=>0, 'msg'=>'signIn error!', 'uid'=>'');
	
    $this->db->select('*');
    $this->db->where('mail', $mail);

    $query = $this->db->get('user');

    $user = $query->result();

    if(!empty($user)) {
        if($password == $user[0]->password && $user[0]->level == 1){
			$result["stat"] = 1;
			$result["msg"] = "signIn success";
			$result["uid"] = $user[0]->id;
			
			return true;
        }
    }
	
	return false;
  }
  
  function getUserList() {
		$this->db->select('*');
		$query = $this->db->get('user');

		$data = array();
		foreach ($query->result() as $row) {
			
			if ($row->level == 0) {
			  $data[] = array(
				'id'=>$row->id,
				'mail'=>$row->mail,
				'name'=>''
			  );
			}
			
		}

		return $data;  
  }
  
  function getHistoryList($uid) {
		$this->db->select('*');
		$this->db->order_by("mDate", "desc");
		$this->db->where('uid', $uid);
		
		$query = $this->db->get('history');

		$data = array();
		foreach ($query->result() as $row) {
		  $data[] = array(
			'id'=>$row->id,
			'amount'=>$row->amount,
			'date'=>date('m/d/Y H:i:s', $row->mDate),
			'kind'=>$row->kind
		  );
		}

		return $data;
   }

  function getNewsList() {
    $this->db->select('*');
	$this->db->order_by("mDate", "desc");
    $query = $this->db->get('news');

    $data = array();
    foreach ($query->result() as $row) {
      $data[] = array(
        'id'=>$row->id,
        'date'=>date('m/d/Y H:i:s', $row->mDate),
        'title'=>$row->title,
        'content'=>$row->content,
        'image'=>$row->image
      );
    }

    return $data;
  }
  
  function addNews($date, $title, $content, $image='') {
		$this->db->set('mDate', $date);
		$this->db->set('title', $title);
		$this->db->set('content', $content);
		$this->db->set('image', $image);
		$this->db->insert('news');
		
		return true;
   }
   
   function updateNews($id, $title, $content, $image='') {
	    $this->db->set('title', $title);
		$this->db->set('content', $content);
		
		if ($image != '')
			$this->db->set('image', $image);
		
		$this->db->where('id', $id);
		$this->db->update('news');
		
		return true;
   }
   
   function delNews($id) {
		$this->db->where('id', $id);
		$this->db->delete('news');
		
		return true;
	}
  
  function getEventsList() {
    $this->db->select('*');
	$this->db->order_by("mDate", "desc");
    $query = $this->db->get('events');

    $data = array();
    foreach ($query->result() as $row) {
      $data[] = array(
        'id'=>$row->id,
        'date'=>date('m/d/Y H:i:s', $row->mDate),
        'title'=>$row->title,
        'content'=>$row->content,
		'place'=>$row->place,
        'image'=>$row->image
      );
    }

    return $data;
  }
  
  function addEvents($date, $title, $content, $place, $image='') {
		$this->db->set('mDate', $date);
		$this->db->set('title', $title);
		$this->db->set('content', $content);
		$this->db->set('place', $place);
		$this->db->set('image', $image);
		$this->db->insert('events');
		
		return true;
  }
  
  function updateEvents($id, $title, $content, $place, $image='') {
	    $this->db->set('title', $title);
		$this->db->set('content', $content);
		$this->db->set('place', $place);
		
		if ($image != '')
			$this->db->set('image', $image);
		
		$this->db->where('id', $id);
		$this->db->update('events');
		
		return true;
   }
   
   function delEvents($id) {
		$this->db->where('id', $id);
		$this->db->delete('events');
		
		return true;
	}

}
