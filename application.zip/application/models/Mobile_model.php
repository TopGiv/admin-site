<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Mobile_model extends CI_Model {

  function signIn($mail/*, $password*/) {
	$result = array('stat'=>0, 'msg'=>'signIn error!', 'uid'=>'');
	
    $this->db->select('*');
    $this->db->where('mail', $mail);

    $query = $this->db->get('user');

    $user = $query->result();

    if(!empty($user)) {
        //if($password == $user[0]->password){
			$result["stat"] = 1;
			$result["msg"] = "signIn success";
			$result["uid"] = $user[0]->id;
        //}
    }
	
	return $result;
  }
  
  function signup($mail/*, $password*/) {
    	$data = array(
      		'mail'=>$mail,
      		//'password'=>$password
    	);
	
	$result = array('stat'=>0, 'msg'=>'signUp error!', 'uid'=>'');
	
	if (!$this->isExistEmail($mail)) {
		$this->db->insert('user', $data);
	}

    	$this->db->select('*');
    	$this->db->where('mail', $mail);
    	$query = $this->db->get('user');

    	$user = $query->result();

    	if(!empty($user)) {
        //if($password == $user[0]->password){
			$result["stat"] = 1;
			$result["msg"] = "signUp success";
			$result["uid"] = $user[0]->id;
        //}
    	}
	
	return $result;
  }
  
  function updateCardInfo($uid, $card_number, $cvc, $card_name) {
	  $result = array('stat'=>1, 'msg'=>'update ok!', 'uid'=>$uid);
	  
	    $this->db->set('card_number', $card_number);
		$this->db->set('cvc', $cvc);
		$this->db->set('card_name', $card_name);
		$this->db->where('id', $uid);
		$this->db->update('user');
		
		return $result;
   }
   
   function getHistoryList($uid) {
		$this->db->select('*');
		$this->db->where('uid', $uid);
		$query = $this->db->get('history');

		$data = array();
		foreach ($query->result() as $row) {
		  $data[] = array(
			'id'=>$row->id,
			'amount'=>$row->amount,
			'date'=>$row->mDate,
			'kind'=>$row->kind
		  );
		}

		return $data;
   }
   
   function addHisstory($mail, $amount, $date, $kind) {
		
		if (!$this->isExistEmail($mail)) {
			$data = array( 'mail'=>$mail );
			$this->db->insert('user', $data);
		}
	
	    	$this->db->select('*');
	    	$this->db->where('mail', $mail);
	    	$query = $this->db->get('user');
		
		$uid = -1;
	    	$user = $query->result();
	    	if(!empty($user)) {
        		$uid = $user[0]->id;
	        }
		
		if ($uid > -1) {
			$this->db->set('uid', $uid);
			$this->db->set('amount', $amount);
			$this->db->set('mDate', $date);
			$this->db->set('kind', $kind);
			$this->db->insert('history');
			
			$result = array('stat'=>1, 'msg'=>'insert ok!', 'uid'=>$uid);
		} else {
			$result = array('stat'=>0, 'msg'=>'insert fail!', 'uid'=>$uid);
		}
		
		return $result;
   }

  function isExistEmail($mail) {
    $this->db->select('id');
    $this->db->where('mail', $mail);

    $query = $this->db->get('user');

    if ($query->num_rows()>0) {
      return true;
    } else {
      return false;
    }
  }

  function getNewsList() {
    $this->db->select('*');
    $query = $this->db->get('news');

    $data = array();
    foreach ($query->result() as $row) {
      $data[] = array(
        'id'=>$row->id,
        'date'=>$row->mDate,
        'title'=>$row->title,
        'content'=>$row->content,
        'image'=>$row->image
      );
    }

    return $data;
  }
  
  function addNews($uid, $date, $title, $content) {
		$result = array('stat'=>1, 'msg'=>'insert ok!', 'uid'=>$uid);
		
		$this->db->set('mDate', $date);
		$this->db->set('title', $title);
		$this->db->set('content', $content);
		$this->db->insert('news');
		
		return $result;
   }
   
   function updateNews($uid, $id, $title, $content) {
	   $result = array('stat'=>1, 'msg'=>'update ok!', 'uid'=>$uid);
	    $this->db->set('title', $title);
		$this->db->set('content', $content);
		$this->db->where('id', $id);
		$this->db->update('news');
		
		return $result;
   }
   
   function updateNewsImage($uid, $id, $path) {
	   $result = array('stat'=>1, 'msg'=>'update ok!', 'uid'=>$uid);
	    $this->db->set('image', $path);
		$this->db->where('id', $id);
		$this->db->update('news');
		
		return $result;
   }
   
   function delNews($uid, $id) {
		$result = array('stat'=>1, 'msg'=>'delete ok!', 'uid'=>$uid);
		
		$this->db->where('id', $id);
		$this->db->delete('news');
		
		return $result;
	}
  
  function getEventsList() {
    $this->db->select('*');
    $query = $this->db->get('events');

    $data = array();
    foreach ($query->result() as $row) {
      $data[] = array(
        'id'=>$row->id,
        'date'=>$row->mDate,
        'title'=>$row->title,
        'content'=>$row->content,
		'place'=>$row->place,
        'image'=>$row->image
      );
    }

    return $data;
  }
  
  function addEvents($uid, $date, $title, $content, $place) {
		$result = array('stat'=>1, 'msg'=>'insert ok!', 'uid'=>$uid);
		
		$this->db->set('mDate', $date);
		$this->db->set('title', $title);
		$this->db->set('content', $content);
		$this->db->set('place', $place);
		$this->db->insert('events');
		
		return $result;
  }
  
  function updateEvents($uid, $id, $title, $content, $place) {
	  $result = array('stat'=>1, 'msg'=>'update ok!', 'uid'=>$uid);
	  
	    $this->db->set('title', $title);
		$this->db->set('content', $content);
		$this->db->set('place', $place);
		$this->db->where('id', $id);
		$this->db->update('events');
		
		return $result;
   }
   
   function updateEventsImage($uid, $id, $path) {
	   $result = array('stat'=>1, 'msg'=>'update ok!', 'uid'=>$uid);
	    $this->db->set('image', $path);
		$this->db->where('id', $id);
		$this->db->update('events');
		
		return $result;
   }
   
   function delEvents($uid, $id) {
		$result = array('stat'=>1, 'msg'=>'delete ok!', 'uid'=>$uid);
		
		$this->db->where('id', $id);
		$this->db->delete('events');
		
		return $result;
	}

}
